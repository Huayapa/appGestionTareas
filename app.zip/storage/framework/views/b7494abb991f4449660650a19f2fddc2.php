<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'task' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'task' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $borderClass = null;
    if ($task?->getDueStatus() === 'Vencido') {
        $borderClass = 'border-red-500';
    }
?>


<div
    class="p-5 pt-4 pb-2 bg-secondary rounded-2xl flex flex-col gap-4 relative border border-transparent <?php echo e($borderClass); ?>">
    
    <div class="absolute top-4 right-4">
        <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <button class="block py-1 px-2 hover:bg-tertiary aspect-square rounded-full transition">
                    <svg width="18" height="4" viewBox="0 0 18 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.75 2.75C9.30228 2.75 9.75 2.30228 9.75 1.75C9.75 1.19772 9.30228 0.75 8.75 0.75C8.19772 0.75 7.75 1.19772 7.75 1.75C7.75 2.30228 8.19772 2.75 8.75 2.75Z"
                            stroke="#EFEFEF" stroke-width="1.5" stroke-linejoin="round" />
                        <path
                            d="M15.75 2.75C16.3023 2.75 16.75 2.30228 16.75 1.75C16.75 1.19772 16.3023 0.75 15.75 0.75C15.1977 0.75 14.75 1.19772 14.75 1.75C14.75 2.30228 15.1977 2.75 15.75 2.75Z"
                            stroke="#EFEFEF" stroke-width="1.5" stroke-linejoin="round" />
                        <path
                            d="M1.75 2.75C2.30228 2.75 2.75 2.30228 2.75 1.75C2.75 1.19772 2.30228 0.75 1.75 0.75C1.19772 0.75 0.75 1.19772 0.75 1.75C0.75 2.30228 1.19772 2.75 1.75 2.75Z"
                            stroke="#EFEFEF" stroke-width="1.5" stroke-linejoin="round" />
                    </svg>
                </button>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('content', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => '/','xData' => '','xOn:click.prevent' => '$dispatch(\'open-modal\', \'edit-task\'); selected = '.e(Js::from([
                        'id' => $task?->id,
                        'title' => $task?->title,
                        'description' => $task?->description,
                        'status' => $task?->status,
                        'due_date' => $task?->due_date,
                    ])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'edit-task\'); selected = '.e(Js::from([
                        'id' => $task?->id,
                        'title' => $task?->title,
                        'description' => $task?->description,
                        'status' => $task?->status,
                        'due_date' => $task?->due_date,
                    ])).'']); ?>
                    Editar
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => '/','xData' => '','xOn:click.prevent' => '$dispatch(\'open-modal\', \'delete-task\'); selected = '.e(Js::from([
                        'id' => $task?->id,
                        'title' => $task?->title,
                        'description' => $task?->description,
                        'status' => $task?->status,
                        'due_date' => $task?->due_date,
                    ])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'delete-task\'); selected = '.e(Js::from([
                        'id' => $task?->id,
                        'title' => $task?->title,
                        'description' => $task?->description,
                        'status' => $task?->status,
                        'due_date' => $task?->due_date,
                    ])).'']); ?>
                    Eliminar
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
    </div>

    
    <div class="pr-6">
        <h3 class="text-lg mb-3"><?php echo e($task?->title); ?></h3>
        <p class="text-sm opacity-70">
            <?php echo e($task?->description); ?>

        </p>
    </div>

    
    <span class="flex items-center justify-center bg-primary rounded-full aspect-square p-1 text-dark text-sm w-[30px]" style="background: <?php echo e(Auth::user()->getUserAKA()['color']); ?>">
        <?php echo e(Auth::user()->getUserAKA()['aka']); ?>

    </span>

    
    
    <div class="flex justify-between items-center h-8">
        <?php if($task?->isDueSoon()): ?>
            <span
                class="inline-flex items-center gap-2 uppercase text-gray-400 font-medium text-xs before:block before:aspect-square before:bg-red-500 before:w-2 before:rounded-full">
                <?php echo e($task?->getDueStatus()); ?>

            </span>
        <?php endif; ?>

        <span class="opacity-70 ms-auto">
            <?php echo e($task?->due_date); ?>

        </span>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\appGestionTareas\resources\views/components/task-card.blade.php ENDPATH**/ ?>