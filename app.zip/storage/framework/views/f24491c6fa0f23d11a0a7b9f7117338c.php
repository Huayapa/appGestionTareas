<nav class="bg-dark hidden sm:flex rounded-xl w-fit xl:w-64 sticky-navigation transition-all">
    <!-- Primary Navigation Menu -->
    <div class="flex flex-col justify-between w-full">
        <div class="flex flex-col">
            <!-- Logo -->
            <div class="shrink-0 flex items-center justify-center px-5 pt-6">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block h-9 w-auto fill-current text-gray-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-9 w-auto fill-current text-gray-800']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                </a>
            </div>

            <!-- Navigation Links -->
            <div class="hidden sm:flex flex-col gap-5 mt-10">
                <?php if (isset($component)) { $__componentOriginalc295f12dca9d42f28a259237a5724830 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc295f12dca9d42f28a259237a5724830 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => route('dashboard'),'active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
                    <div class="w-10 aspect-square xl:w-8">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z"
                                fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M12.37 8.87988H17.62" stroke="#343434" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M6.38 8.87988L7.13 9.62988L9.38 7.37988" stroke="#343434" stroke-width="1.5"
                                stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M12.37 15.8799H17.62" stroke="#343434" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <path d="M6.38 15.8799L7.13 16.6299L9.38 14.3799" stroke="#343434" stroke-width="1.5"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </div>
                    <span class="hidden xl:block">
                        Tareas
                    </span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $attributes = $__attributesOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__attributesOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $component = $__componentOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__componentOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginalc295f12dca9d42f28a259237a5724830 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc295f12dca9d42f28a259237a5724830 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => route('profile.edit'),'active' => request()->routeIs('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('profile.edit'))]); ?>
                    <svg width="35" height="35" viewBox="0 0 24 25" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M12 10.6665C14.2091 10.6665 16 8.87564 16 6.6665C16 4.45736 14.2091 2.6665 12 2.6665C9.79086 2.6665 8 4.45736 8 6.6665C8 8.87564 9.79086 10.6665 12 10.6665Z"
                            fill="currentColor" />
                        <path
                            d="M20 18.1665C20 20.6515 20 22.6665 12 22.6665C4 22.6665 4 20.6515 4 18.1665C4 15.6815 7.582 13.6665 12 13.6665C16.418 13.6665 20 15.6815 20 18.1665Z"
                            fill="currentColor" />
                    </svg>
                    <span class="hidden xl:block">
                        Perfil
                    </span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $attributes = $__attributesOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__attributesOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $component = $__componentOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__componentOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>" class="p-5">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['class' => 'w-full px-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full px-3']); ?>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M3.85525 11.2684C3.65153 11.4381 3.38878 11.5199 3.12475 11.4959C2.86072 11.4719 2.61703 11.344 2.44725 11.1404L0.364247 8.6404C0.201982 8.4359 0.126123 8.17604 0.152877 7.91636C0.179631 7.65667 0.306874 7.41775 0.507426 7.25062C0.707978 7.08349 0.965937 7.00142 1.22619 7.02193C1.48644 7.04245 1.72835 7.16392 1.90025 7.3604L3.98325 9.8604C4.15291 10.0641 4.23474 10.3269 4.21073 10.5909C4.18673 10.8549 4.05887 11.0986 3.85525 11.2684Z"
                        fill="white" />
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M3.85661 4.73212C4.06038 4.90176 4.18843 5.14538 4.21262 5.40941C4.23681 5.67344 4.15516 5.93627 3.98561 6.14012L1.90161 8.64012C1.81873 8.74457 1.7158 8.8314 1.59887 8.89548C1.48193 8.95957 1.35337 8.99962 1.22073 9.01329C1.08809 9.02695 0.954052 9.01395 0.826511 8.97505C0.69897 8.93615 0.580497 8.87214 0.478061 8.78678C0.375625 8.70141 0.291295 8.59642 0.230033 8.47799C0.168772 8.35955 0.131815 8.23006 0.121337 8.09713C0.11086 7.9642 0.127073 7.83052 0.169023 7.70395C0.210973 7.57738 0.277813 7.46047 0.36561 7.36012L2.44861 4.86012C2.61839 4.6565 2.86208 4.52863 3.12611 4.50463C3.39014 4.48063 3.65289 4.56245 3.85661 4.73212Z"
                        fill="white" />
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M1.38281 8C1.38281 7.73478 1.48817 7.48043 1.67571 7.29289C1.86324 7.10536 2.1176 7 2.38281 7L8.88281 7C9.14803 7 9.40238 7.10536 9.58992 7.29289C9.77746 7.48043 9.88281 7.73478 9.88281 8C9.88281 8.26522 9.77746 8.51957 9.58992 8.70711C9.40238 8.89464 9.14803 9 8.88281 9L2.38281 9C2.1176 9 1.86324 8.89464 1.67571 8.70711C1.48817 8.51957 1.38281 8.26522 1.38281 8ZM15.8828 15C15.8828 15.2652 15.7775 15.5196 15.5899 15.7071C15.4024 15.8946 15.148 16 14.8828 16L5.88281 16C5.6176 16 5.36324 15.8946 5.17571 15.7071C4.98817 15.5196 4.88281 15.2652 4.88281 15C4.88281 14.7348 4.98817 14.4804 5.17571 14.2929C5.36324 14.1054 5.6176 14 5.88281 14L14.8828 14C15.148 14 15.4024 14.1054 15.5899 14.2929C15.7775 14.4804 15.8828 14.7348 15.8828 15ZM15.8828 1C15.8828 1.26522 15.7775 1.51957 15.5899 1.70711C15.4024 1.89464 15.148 2 14.8828 2L5.88281 2C5.6176 2 5.36324 1.89464 5.17571 1.70711C4.98817 1.51957 4.88281 1.26522 4.88281 0.999999C4.88281 0.734782 4.98817 0.480428 5.17571 0.292892C5.36324 0.105355 5.6176 -8.97414e-07 5.88281 -8.74228e-07L14.8828 -8.74228e-08C15.148 -6.42368e-08 15.4024 0.105356 15.5899 0.292892C15.7775 0.480429 15.8828 0.734783 15.8828 1Z"
                        fill="white" />
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M5.88281 16C5.6176 16 5.36324 15.8946 5.17571 15.7071C4.98817 15.5196 4.88281 15.2652 4.88281 15L4.88281 11C4.88281 10.7348 4.98817 10.4804 5.17571 10.2929C5.36324 10.1054 5.6176 10 5.88281 10C6.14803 10 6.40238 10.1054 6.58992 10.2929C6.77746 10.4804 6.88281 10.7348 6.88281 11L6.88281 15C6.88281 15.2652 6.77746 15.5196 6.58992 15.7071C6.40238 15.8946 6.14803 16 5.88281 16ZM5.88281 6C5.6176 6 5.36324 5.89464 5.17571 5.70711C4.98817 5.51957 4.88281 5.26522 4.88281 5L4.88281 0.999999C4.88281 0.734782 4.98817 0.480428 5.17571 0.292892C5.36324 0.105355 5.6176 -8.97414e-07 5.88281 -8.74228e-07C6.14803 -8.51042e-07 6.40238 0.105355 6.58992 0.292892C6.77746 0.480428 6.88281 0.734782 6.88281 0.999999L6.88281 5C6.88281 5.26522 6.77746 5.51957 6.58992 5.70711C6.40238 5.89464 6.14803 6 5.88281 6ZM14.8828 16C14.6176 16 14.3632 15.8946 14.1757 15.7071C13.9882 15.5196 13.8828 15.2652 13.8828 15L13.8828 1C13.8828 0.734783 13.9882 0.480429 14.1757 0.292892C14.3632 0.105356 14.6176 -1.10609e-07 14.8828 -8.74228e-08C15.148 -6.42368e-08 15.4024 0.105356 15.5899 0.292892C15.7775 0.480429 15.8828 0.734783 15.8828 1L15.8828 15C15.8828 15.2652 15.7775 15.5196 15.5899 15.7071C15.4024 15.8946 15.148 16 14.8828 16Z"
                        fill="white" />
                </svg>
                <span class="hidden xl:block">
                    Cerrar sesión
                </span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
        </form>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\laravel\appGestionTareas\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>